import threading
import time


class connectManager(threading.Thread):
    
    def __init__(self, connList):
        self.connectList = connList
        super(connectManager, self).__init__()

    def run(self):
        
        self.isConnected = 1
        while True:
            time.sleep(0.1)
            
            if not self.connectList:
                continue

            try:
                for conSock in self.connectList:
                    
                    userId = conSock.getUserId()
                    getMsg = conSock.getMessage()
                    
                    if getMsg:
                        for otherSock in self.connectList:
                            if userId == otherSock.getUserId():
                                continue
                            
                            strMsg = userId + "> " + getMsg
                            otherSock.sendToClient(strMsg)
                            conSock.setMessage()
                        

            except Exception as e:
                print (e)
                print ("Can't send to Client")

    def sendAllMessage(self, message):
        for conSock in self.connectList:
            conSock.sendToClient(message)