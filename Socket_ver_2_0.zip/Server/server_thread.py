import sys
import threading
from time import ctime

BUFSIZE = 1024


class servThread(threading.Thread):

    isConnected = 0
    message = ''
    def __init__(self, socket, ADDR, userId):
        super(servThread, self).__init__()
        self.socket = socket
        self.ip = ADDR[0]
        self.port = ADDR[1]
        self.userId = userId

    def run(self):
        try:
            print('Server Thread[%s] is started.' % self.ip)
            sys.stdout.flush()

            while True:
                byteData = self.socket.recv(BUFSIZE)                
                strData = byteData.decode("utf-8")
                
                self.message = strData
                print ('Received Data[%s] ' % strData)
                sys.stdout.flush()

                if strData == 'exit':
                    break

        except Exception as e:
            self.sockClose()
            print (e)

    def printSoc(self):
        print('[INFO][%s] New Connection - %s' % (ctime(), self.userId))
        
    def sendToClient(self, strMsg):
        byteData = strMsg.encode(encoding='utf_8', errors='strict')
        try:
            self.socket.send(byteData)
            
        except Exception as e:
            self.sockClose()
            print (e)
            
    def getUserId(self):
        return self.userId
    
    def getMessage(self):
        return self.message
    
    def setMessage(self):
        self.message = ''
    
    def sockClose(self):
        
        if self.isConnected == 1:
            self.socket.close()
            print ('[Disconnected] %s' % self.userId)