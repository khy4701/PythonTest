from select import *
from socket import *
import sys
import threading
import time

sys.path.append("D:/Users/Ariel/workspace/Socket_ver_2_0")

from Client.client_thread import *
from WebServer.manager import *



HOST = 'localhost'
PORT = 1234
ADDR = (HOST, PORT)  

clientSocket = []

        
if __name__ == '__main__':
    
    try:
        # 02. Try Connection

        clientSocket = socket(AF_INET, SOCK_STREAM)
        clientSocket.connect(ADDR)

    except Exception as e:
        print("Can't Connect to server(%s:%s)" % ADDR)
        sys.exit()
    
    print("Connect Success to Server(%s:%s)" % ADDR)

    
    webManager = loginManager()
    result = webManager.login()
    
    if(result != 200):
        sys.exit()

    # Receive Thread Start
    client = cliThread(clientSocket)
    client.start()

    while True:
        try:
            data = input()
            print("<Me> " + data)
            sys.stdout.flush()
            
            byteData = data.encode(encoding='utf_8', errors='strict')
            clientSocket.send(byteData)

        except KeyboardInterrupt:
            clientSocket.close()
            print ('Socket Closed')
            sys.stdout.flush()
            sys.exit()
            
