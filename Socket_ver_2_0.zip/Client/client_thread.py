import sys
import threading

BUFSIZE = 1024

class cliThread(threading.Thread):

    def __init__(self, cliSock):
        self.clientSock = cliSock
        super(cliThread, self).__init__()
        
    
    def run(self):       
                               
        while True:
            sys.stdout.flush()
            byteData = self.clientSock.recv(BUFSIZE)

            strMsg = byteData.decode("utf-8")

            if not strMsg:
                continue

            print (strMsg)  