import requests

class loginManager():
    
    def __init__(self):
        self.url = 'http://localhost'
            
    def login(self):
        
        result = requests.get(self.url)
        
        plain_text = result.text
        print(result.status_code)
        print(plain_text)
        
        return result.status_code
        
        
        