import threading
import time

from Server.server_thread import servThread
from Util.Room import room


class connectManager(threading.Thread):
            
    roomIdx = 0
    def __init__(self, connList ,roomList):
        self.connectList = connList
        self.roomList    = roomList
        super(connectManager, self).__init__()

    def run(self):
        
        cnt = 0
        self.isConnected = 1
        while True:
            time.sleep(0.1)
                                                
            if not self.connectList:
                continue
                        
            if cnt == 10:
                self.checkConnection()
                #self.sendConnectList()
                cnt = 0                
            cnt+=1

            try:
                for conSock in self.connectList:
                    
                    userId = conSock.getUserId()
                    getMsg = conSock.getMessage()                                
                    
                    if not getMsg:
                        continue
                    
                    print ( servThread.userNum )
                        
                    if servThread.userNum == 1:
                        conSock.setMessage()
                        break
                        
                    for otherSock in self.connectList:
                        if userId == otherSock.getUserId():
                            continue
                        
                        strMsg = userId + "> " + getMsg
                        otherSock.sendToClient(strMsg)
                        conSock.setMessage()
                        
            except Exception as e:
                print(e)
                print ("Can't send to Client")
                

    def sendBroadCasting(self, message, msgType):
        
        try :
            for conSock in self.connectList:
                conSock.sendToClient(message, msgType)
        except Exception as e:
            self.deleteDeadUser(conSock)
            
                        
    def deleteDeadUser(self, conSock):        
        self.sendBroadCasting('DisConnected %s ..' %conSock.getUserId(), 1)
        self.connectList.remove(conSock)
        conSock.stopThread()
        servThread.userNum -= 1

    def checkConnection(self):
        
        for conSock in self.connectList:
            if conSock.getStatus() == "DEAD":
                conSock.sendToClient("DEAD?", 1)
                self.deleteDeadUser(conSock)
                
    def sendConnectList(self):
        try:
            userList = []
            
            if not self.connectList:
                return 1
            
            for conSock in self.connectList:
                userList.append(conSock.getUserId())     
            
            self.sendBroadCasting(userList, 3)       
            
        except Exception as e:
            print(e) 
            
    def addRoomList(self, msg):
        
        self.roomIdx += 1
        roomMsg = msg.split("#")
        roomInfo = room(self.roomIdx, roomMsg[0], roomMsg[1], roomMsg[2])
        self.roomList.append(roomInfo)
        
    def sendRoomList(self):
        
        try:
            roomList = []
            
            if not self.roomList:
                return 1
            
            if not self.connectList:
                return 1
        
            for roomInfo in self.roomList:
                roomList.append(roomInfo.getRoomName())
            
            self.sendBroadCasting(roomList, 100)   
        except Exception as e:
            print(e)

        
        