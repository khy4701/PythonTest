import sys
import threading
from time import ctime

from Util.Message import *
import _pickle as cPickle

BUFSIZE = 1024

class servThread(threading.Thread):
    
    userNum = 0
    isConnected = 0
    message = ''
    
    def __init__(self, socket, ADDR, connManager):
        super(servThread, self).__init__()
        self.socket = socket
        self.ip = ADDR[0]
        self.port = ADDR[1]
        self.userId = 'Default'
        self.connManager = connManager
        self.status = 'ALIVE'
        
        servThread.userNum += 1

    def run(self):
        try:
            print('Server Thread[%s] is started.' % self.ip)
            sys.stdout.flush()

            while True:
                self.readfile = self.socket.makefile('rb', 1024)
                self.readPicker = cPickle.Unpickler(self.readfile)
                
                msg = self.readPicker.load()
                self.readfile.close()
                                 
                strData = msg.getMessageData()
                msgType = msg.getMessageType()
                
                if msgType == 0:
                    self.userId = strData
                    print ('User[%s] Information Received..' % self.userId)
                    continue
                    
                elif msgType == 1:                                      
                    self.message = strData
                    print ('[%s] :  [%s] ' %( self.userId,strData))
                    sys.stdout.flush()
                
                elif msgType == 2:                    
                    self.status = 'DEAD'           
                                
                elif msgType == 100:
                    self.connManager.addRoomList(strData)
                    self.connManager.sendRoomList()
                                
                else:
                    print ('Received Unknown Message')

                if strData == 'exit':
                    break

        except Exception as e:
            self.sockClose()
            print (e)

    def printSoc(self):
        print('[INFO][%s] New Connection - %s' % (ctime(), self.userId))
        
    def sendToClient(self, strMsg , msgType):
     
        if isinstance(strMsg, str):
            msg = msgClass("Server", strMsg, 1)
            print ('Send to client : %s' %strMsg)

        elif isinstance(strMsg, list):
            msg = msgClass("Server", '', msgType)
            if msgType == 3:
                msg.setUserList(strMsg)
            elif msgType == 100:
                msg.setRoomList(strMsg)

        try:               
            self.writefile = self.socket.makefile('wb', 1024 )
            self.writePicker = cPickle.Pickler(self.writefile)         
            self.writePicker.dump(msg)         
            self.writefile.close()
 
        except Exception as e:
            self.sockClose()
            print (e)
            
    def getUserId(self):
        return self.userId
    
    def getMessage(self):
        return self.message
    
    def setMessage(self):
        self.message = ''
    
    def sockClose(self):
        
        if self.isConnected == 1:
           
            self.socket.close()
            print ('[Disconnected] %s' % self.userId)
            
    def stopThread(self):
        self.run = False
        
    def getStatus(self):
        return self.status
        