import sys
sys.path.append("D:/Users/Ariel/workspace/Socket_ver_2_0")

from select import *
from socket import *
from Client.client_thread import *

import threading
import time


class Socket():
    
    def __init__(self, host, port):
    
        try:
            # 02. Try Connection
            self.host = host
            self.port = port
            self.ADDR = (self.host, self.port)
            
            self.clientSocket = socket(AF_INET, SOCK_STREAM)
            self.clientSocket.connect(self.ADDR)
        
        except Exception as e:
            print("Can't Connect to server(%s:%s)" % self.ADDR)
            
            sys.exit()
            
        print("Connect Success to Server(%s:%s)" % self.ADDR)

            
    def startSocket(self, MainThread):
        client = cliThread(self.clientSocket, MainThread)
        client.start()
        
    def sockClose(self):
        try:
            self.clientSocket.close()
        except Exception as e:
            print (e)
                    
    def sendToServer(self, text):
        try:
            self.clientSocket.send(text)
        except Exception as e:
            print(e)
            self.clientSocket.close()
            sys.exit()
