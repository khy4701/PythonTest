import sys

sys.path.append("D:/Users/Ariel/workspace/Socket_ver_2_0")

from PyQt5 import QtCore, QtGui, QtWidgets

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import QMainWindow, QApplication

from Client.client_socket import *
from WebServer.manager import *      

class guiMain(QMainWindow):
    
    def __init__(self):
        super().__init__()
        self.initUI()

        self.socket = Socket('localhost', 1234)
        self.socket.startSocket(self)
              
             
    def initUI(self):      

        self.setObjectName("Dialog")
        self.resize(400, 300)
        self.buttonBox = QtWidgets.QDialogButtonBox(self)
        self.buttonBox.setGeometry(QtCore.QRect(50, 270, 341, 32))
        self.buttonBox.setOrientation(QtCore.Qt.Horizontal)
        self.buttonBox.setStandardButtons(QtWidgets.QDialogButtonBox.Cancel|QtWidgets.QDialogButtonBox.Ok)
        self.buttonBox.setObjectName("buttonBox")
        self.textBrowser = QtWidgets.QTextBrowser(self)
        self.textBrowser.setGeometry(QtCore.QRect(110, 20, 271, 201))
        self.textBrowser.setObjectName("textBrowser")
        self.listView = QtWidgets.QListView(self)
        self.listView.setGeometry(QtCore.QRect(10, 20, 91, 201))
        self.listView.setObjectName("listView")
        self.lineEdit = QtWidgets.QLineEdit(self)
        self.lineEdit.setGeometry(QtCore.QRect(10, 240, 371, 21))
        self.lineEdit.setObjectName("lineEdit")

        self.setWindowModality(QtCore.Qt.NonModal)

        self.retranslateUi(self)
        QtCore.QMetaObject.connectSlotsByName(self)
            
    def retranslateUi(self, Dialog):
        _translate = QtCore.QCoreApplication.translate
        Dialog.setWindowTitle(_translate("Dialog", "Dialog"))
               
    def tryLogin(self):
        
        self.id = self.le_id.text()
        self.pw = self.le_pw.text()
        
        print( "ID[%s] ,PW[%s] try to connect" %(self.id ,self.pw) )
        
        #web authentication
        webManager = loginManager()
        result = webManager.login(self.id, self.pw)
        
        if(result == "Success"):
            self.showDialog()
                    
    def tryRegister(self):
                   
        self.id = self.le_id.text()
        self.pw = self.le_pw.text()
                                           
        #web authentication
        webManager = loginManager()
        result = webManager.register(self.id, self.pw)        
        print (result)
            
    def onChanged(self, text):        
        self.lbl.setText(text)
        self.lbl.adjustSize()    
        
    def keyPressEvent(self, e):        
        if e.key() == Qt.Key_Escape:
            self.close()
            
        if e.key() == QtCore.Qt.Key_Return:
            print (self.lineEdit.text())
            self.send(self.lineEdit.text())
        else:
            super().keyPressEvent(e)
            
    def send(self, text):
        
        self.lineEdit.setText('')
        self.printBoard("<ME> : "+text)
                       
        
        byteData = text.encode(encoding='utf_8', errors='strict')
        self.socket.sendToServer(byteData)
            
    def printBoard(self, text):
        self.textBrowser.append(text)
        self.textBrowser.update()
        
