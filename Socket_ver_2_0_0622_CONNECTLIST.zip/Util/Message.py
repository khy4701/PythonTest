
class msgClass():
    
    sendUser = ""
    destUser = ""    
    msgData  = ""
    msgType  = 0      # 0 : Connection , 1: Message , 2: DisConnection, 3:UserList
    userList = [] 
    
    def __init__(self, send, msgData ,msgType):
        self.sendUser = send
        self.msgData = msgData
        self.msgType = msgType
        
    
        
    def setMessageData(self, text, type):
        
        # configure[0], Message[1]
        self.msgType = type  
        self.msgData = text
        
    def getMessageData(self):
        return self.msgData
    
    def converByteToString(self, byteData):
        return byteData.decode("utf-8")
        
    def converStringToByte(self, strData):        
        return strData.encode(encoding='utf_8', errors='strict')   
    
    def isGetMessage(self):
        if self.msgData:
            return "true"            
                     
    def getUserInfo(self):
        userInfo = (self.sendUser, self.destUser)
        return userInfo
    
    def getsendUser(self):
        return self.sendUser

    def getMessageType(self):
        return self.msgType
    
    def setUserList(self, userList):
        self.userList = userList
                
    def getUserList(self):
        return self.userList
        
        