import threading
import time
from Server.server_thread import servThread

class connectManager(threading.Thread):
            
    def __init__(self, connList):
        self.connectList = connList
        super(connectManager, self).__init__()

    def run(self):
        
        cnt = 0
        self.isConnected = 1
        while True:
            time.sleep(0.1)
                                                
            if not self.connectList:
                continue
                        
            if cnt == 10:
                self.checkConnection()
                self.sendConnectList()
                cnt = 0                
            cnt+=1

            try:
                for conSock in self.connectList:
                    
                    userId = conSock.getUserId()
                    getMsg = conSock.getMessage()                                
                    
                    if not getMsg:
                        continue
                    
                    print ( servThread.userNum )
                        
                    if servThread.userNum == 1:
                        conSock.setMessage()
                        break
                        
                    for otherSock in self.connectList:
                        if userId == otherSock.getUserId():
                            continue
                        
                        strMsg = userId + "> " + getMsg
                        otherSock.sendToClient(strMsg)
                        conSock.setMessage()
                        
            except Exception as e:
                print(e)
                print ("Can't send to Client")
                

    def sendBroadCasting(self, message):
        
        try :
            for conSock in self.connectList:
                conSock.sendToClient(message)
        except Exception as e:
            self.deleteDeadUser(conSock)
            
                        
    def deleteDeadUser(self, conSock):        
        self.sendBroadCasting('DisConnected %s ..' %conSock.getUserId())
        self.connectList.remove(conSock)
        conSock.stopThread()
        servThread.userNum -= 1

    def checkConnection(self):
        
        for conSock in self.connectList:
            if conSock.getStatus() == "DEAD":
                conSock.sendToClient("DEAD?")
                self.deleteDeadUser(conSock)
                
    def sendConnectList(self):
        try:
            userList = []
            
            if not self.connectList:
                return 1
            
            for conSock in self.connectList:
                userList.append(conSock.getUserId())     
            
            self.sendBroadCasting(userList)       
            
        except Exception as e:
            print(e) 