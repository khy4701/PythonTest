import sys

sys.path.append("D:/Users/Ariel/workspace/Socket_ver_2_0")

import threading
import _pickle as cPickle
from Util import Message

BUFSIZE = 1024

class cliThread(threading.Thread):

    def __init__(self, cliSock, MainThread):
        self.clientSock = cliSock
        self.mainTh     = MainThread
        super(cliThread, self).__init__()
        
    
    def run(self):       
                               
        while True:
            sys.stdout.flush()
            
            
            file = self.clientSock.makefile('rb', 1024)
            msg = cPickle.load(file)
            file.close()
            
            
            #byteData = self.clientSock.recv(BUFSIZE)

            #strMsg = byteData.decode("utf-8")
            
            if msg.isGetMessage() != "true":
                continue
            
            strMsg = msg.getMessageData()

            self.mainTh.printBoard(strMsg)
            print(strMsg)
