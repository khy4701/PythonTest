import sys
import threading
from time import ctime

from Util.Message import *
import _pickle as cPickle


BUFSIZE = 1024


class servThread(threading.Thread):

    isConnected = 0
    message = ''
    def __init__(self, socket, ADDR, userId):
        super(servThread, self).__init__()
        self.socket = socket
        self.ip = ADDR[0]
        self.port = ADDR[1]
        self.userId = userId

    def run(self):
        try:
            print('Server Thread[%s] is started.' % self.ip)
            sys.stdout.flush()

            while True:
                
                file = self.socket.makefile('rb', 1024)
                msg = cPickle.load(file)
                file.close()
                
                strData = msg.getMessageData()
                
                self.message = strData
                print ('Received Data[%s] ' % strData)
                sys.stdout.flush()

                if strData == 'exit':
                    break

        except Exception as e:
            self.sockClose()
            print (e)

    def printSoc(self):
        print('[INFO][%s] New Connection - %s' % (ctime(), self.userId))
        
    def sendToClient(self, strMsg):
        
                   
       # byteData = strMsg.encode(encoding='utf_8', errors='strict')
        try:
            #self.socket.send(byteData)
            msg = msgClass("Server", strMsg)
            file = self.socket.makefile('wb', 1024 )
            cPickle.dump(msg, file)            
            file.close() 
            
        except Exception as e:
            self.sockClose()
            print (e)
            
    def getUserId(self):
        return self.userId
    
    def getMessage(self):
        return self.message
    
    def setMessage(self):
        self.message = ''
    
    def sockClose(self):
        
        if self.isConnected == 1:
            self.socket.close()
            print ('[Disconnected] %s' % self.userId)